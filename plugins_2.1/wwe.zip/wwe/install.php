<?php
/*
Plugin Name: WWE
Plugin Key: A10
Plugin Icon: https://i.imgur.com/Oq39n4Y.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/wwe.com\/videos\/([a-z1-9.-_]+)/"; "url_line":"/de.wwe.com\/videos\/([a-z1-9.-_]+)/"; "url_line":"/espanol.wwe.com\/videos\/([a-z1-9.-_]+)/"; "url_line":"/arabic.wwe.com\/videos\/([a-z1-9.-_]+)/";
*/
?>