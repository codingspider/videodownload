<?php
/*
Plugin Name: bandcamp
Plugin Key: A22
Plugin Icon: https://i.imgur.com/uqyh5zc.png
Update date: 10-07-2019
Version: 1.0
Author: Zhareiv
Url_line: "url_line":"/([a-z1-9.-_]+)(.+)bandcamp.com\/track\/([a-z1-9.-_]+)/";
*/
?>  