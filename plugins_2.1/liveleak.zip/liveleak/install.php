<?php
/*
Plugin Name: Liveleak
Plugin Key: A8
Plugin Icon: https://i.imgur.com/kayDrTR.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/liveleak.com\/([a-z1-9.-_]+)/";
*/
?>