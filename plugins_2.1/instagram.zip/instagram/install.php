<?php
/*
Plugin Name: Instagram
Plugin Key: A2
Plugin Icon: https://i.imgur.com/AGsW88w.png
Update date: 18-06-2019
Version: 1.4
Author: Zhareiv
Url_line: "url_line":"/instagram.com\/p\/([a-z1-9.-_]+)/";
*/
?>