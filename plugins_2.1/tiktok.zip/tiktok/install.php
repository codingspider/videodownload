<?php
/*
Plugin Name: TikTok
Plugin Key: A13
Plugin Icon: https://i.imgur.com/bO21kdQ.png
Update date: 06-07-2019
Version: 1.5
Author: zhareiv
Url_line: "url_line":"/m.tiktok.com\/v\/([^&]+)/"; "url_line":"/vm.tiktok.com\/([^&]+)/"; "url_line":"/tiktok.com\/share\/video\/([^&]+)/"; "url_line":"/tiktok.com\/([a-z1-9.-_]+)\/video\/([^&]+)/";
*/
?>