<?php
/*
Plugin Name: vimeo
Plugin Key: A4
Plugin Icon: https://i.imgur.com/bd2jB2B.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/vimeo.com\/([a-z1-9.-_]+)/";
*/
?>