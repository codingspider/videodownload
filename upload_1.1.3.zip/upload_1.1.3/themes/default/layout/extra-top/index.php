<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="{{CONFIG theme_url}}/css/main.css?n=1">
<link rel="stylesheet" href="{{CONFIG theme_url}}/css/home.css?n=1">
<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
<link rel="stylesheet" href="{{CONFIG theme_url}}/css/share.css?n=1">
<link rel="stylesheet" href="{{CONFIG theme_url}}/css/main_m.css?n=1">
<link rel="stylesheet" href="{{CONFIG theme_url}}/css/main_rotation.css?n=1">
<link rel="alternate" href="{{CONFIG site_url}}/es/" hreflang="es" />
<link rel="alternate" href="{{CONFIG site_url}}/en/" hreflang="en" />
<link rel="alternate" href="{{CONFIG site_url}}/de/" hreflang="de" />
<link rel="alternate" href="{{CONFIG site_url}}/fr/" hreflang="fr" />
<link rel="alternate" href="{{CONFIG site_url}}/it/" hreflang="it" />
<link rel="alternate" href="{{CONFIG site_url}}/pt/" hreflang="pt" />
<link rel="alternate" href="{{CONFIG site_url}}/ru/" hreflang="ru" />
<link rel="alternate" href="{{CONFIG site_url}}/tr/" hreflang="tr" />
<link rel="alternate" href="{{CONFIG site_url}}/zh/" hreflang="zh-CN" />
<!--link rel="alternate" href="{{CONFIG site_url}}/zh-tw/" hreflang="zh-TW" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/sa/" hreflang="sa" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/jp/" hreflang="ja" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/kr/" hreflang="ko" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/mm/" hreflang="my" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/my/" hreflang="ms" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/ph/" hreflang="en-PH" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/ru/" hreflang="ru" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/vi/" hreflang="vi" /-->
<!--link rel="alternate" href="{{CONFIG site_url}}/hi/" hreflang="hi" /-->
<!-- Latest compiled and minified JavaScript -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- bootstrap Latest compiled and minified CSS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>