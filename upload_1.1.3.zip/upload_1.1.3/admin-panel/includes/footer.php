
<script src="./assets/js/script_js_two.js"></script>
<footer>
	PANEL ADMIN
</footer>