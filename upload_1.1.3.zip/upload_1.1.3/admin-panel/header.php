<html lang="en">
	<head>
		<link href="./assets/css/main.css?n=1" rel="stylesheet" type="text/css">
		<!-- this CSS file is for mobile phones and tablets -->
		<link href="./assets/css/main_m.css?n=1" rel="stylesheet" type="text/css">
		<!-- Ajax jquery -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
		<!-- bootstrap Latest compiled and minified CSS -->
		<script src="./assets/extensions/bootstrap.min.js"></script>
		<script src="./assets/extensions/jquery-3.2.1.min.js"></script>
		<script src="./assets/js/script_js.js"></script>
		<link rel="icon" type="image/png" size="16x16" href="assets/img/favicon.png">
		<title><?php echo $titule_site; ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta charset="UTF-8">
	</head>
	<body>
	