<?php
// tables
define('T_CONFIG', 'config');
define('T_MEDIA', 'platform_media');
define('T_SHARE', 'share_urls');
define('T_USER', 'user_data');
define('T_REPORT_LINK', 'report_link');


?>