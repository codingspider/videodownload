{{HEADER_TOP}}
<div class="page-margin-404">
	<div class="content">
		<div class="top_div_404">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center">
						<br>
						<h2 class="text_h2_404">{{LANG 404_title}}</h2>
						<p class="text_p_404">{{LANG_404_DESC}}</p>
						<a class="link_logo" href="./">
							<span class="text_span_404">
								<i class="icon_404 fas fa-chevron-left"></i>{{LANG Back_search}}
							</span>
						</a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>