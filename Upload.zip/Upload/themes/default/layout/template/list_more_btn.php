<div id="<?php echo $postID; ?>" class="show_more btn_loader_more_data" >
	<div class="show_more_main" id="show_more_main<?php echo $postID; ?>">
		<span  title="Load more posts"><i class="fas fa-arrow-down"></i></span>
		<span class="loding" style="display: none;"><i class="fa fa-spinner fa-spin"></i></span>
	</div>
</div>
<br>