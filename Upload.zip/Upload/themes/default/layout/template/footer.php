<div class="class_footer">
	<p class="class_footer_p_text">
		<b>{{NAME_SITE}}</b> Made with ❤️ by Csode<span> - {{DATA_YEAR}}</span>
	</p>
</div>