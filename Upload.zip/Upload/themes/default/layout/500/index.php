<div class="page-margin">
	<div class="content">
		<div class="top-video">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center">
						<h2>{{TEXT 500_title}}</h2>
						<p>{{TEXT 500_desc}}</p>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>