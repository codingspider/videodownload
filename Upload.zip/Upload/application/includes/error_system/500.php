<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
<style>
	body {
	    background: #f5f5f5;
		margin: auto;
	}

	.page_500 {
		background: #fff;
		width: 35%;
		height: fit-content;
		border: 1px solid #d8d8d8;
		margin-top: 16%;
		margin-left: 32%;
	}
	
	.content {
		
	}
	
	.top_magin {
		
	}
	
	.row {
		
	}
	
	.col-md-12 {
		
	}
	
	.text-center {
		text-align: center;
	}
	
	h2 {
		font-size: 22px;
	}
	
	p {
		font-size: 14px;
	}
</style>
<title>HTTP Error 500 - Internal server error</title>
<div class="col-md-4 page_500">
	<div class="content">
		<div class="top_magin">
			<div class="row">
				<div class="col-md-12">
					<div class="text-center">
						<img src="./application/img/server.png"></img>
						<h2>500 Internal Server Error</h2>
						<p>HTTP Error 500 - Internal server error
The Web server encountered an unexpected condition that prevented it from fulfilling the request by the client (e.g. your Web browser)for access to the requested URL.</p>
						<p><a  href="./">Retry</a></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

