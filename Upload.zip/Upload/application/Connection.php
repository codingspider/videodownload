<?php
// +------------------------------------------------------------------------+
// | @author shareiv or csode and scode
// | Copyright (c) 2017 shareiv. All rights reserved.
// +------------------------------------------------------------------------+
date_default_timezone_set('UTC');
session_start();
require_once ('system/cache.php');
require_once ('system/tables.php');
require_once ('system/function_app.php');
require_once ('system/function_security.php');



 