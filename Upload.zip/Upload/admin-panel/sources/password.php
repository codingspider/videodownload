<section id="wall_section">
	<div class="name_session_t">
		<p class="name_session_text"><?php echo $lags29; ?><br><spam class="name_session_text_spam"><?php echo $lags30; ?></spam></p>
	</div>
	<div class="div_statistics_panel">
	<form method="post" action="content_data.php?data=password" charset="UTF-8">
		<div class="wall_class_settings">
			<p class="text_p"><?php echo $lags32; ?></p>
			<input class="class_settings_input" type="text" name="email" value="<?php echo $email; ?>"/>
			<p class="text_p"><?php echo $lags10; ?></p>
			<input class="class_settings_input" type="password" name="password" placeholder="<?php echo $lags10; ?>"/>
			<br>
			<br>
			<center>
				<input class="button_admin_more" type="submit" value="<?php echo $lags5; ?>"/> 
			</center>
		</div>
	</form>	
	</div>
</section>