<section id="wall_section">
	<div class="name_session_t">
		<p class="name_session_text"><?php echo $lags45; ?><br><spam class="name_session_text_spam"><?php echo $lags45; ?></spam></p>
	</div>
	<div class="div_statistics_panel">
	<form method="post" action="content_data.php?data=pages" charset="UTF-8">
		<div class="wall_class_settings">
			<p class="text_p"><?php echo $lags46; ?></p>
			<textarea  class="class_settings_textarea" name="t_of" id="t_of" cols="60" rows="40"><?php echo data_script('12','SELECT');?></textarea><br><br>
			<p class="text_p"><?php echo $lags47; ?></p>
			<textarea  class="class_settings_textarea" name="p_py" id="p_py" cols="60" rows="40"><?php echo data_script('13','SELECT');?></textarea><br><br>
			<br> 
			<br> 
			<br> 
			<center>
				<input class="button_admin_more" type="submit" value="<?php echo $lags5; ?>"/> 
			</center>
		</div>
	</form>
	<br>	
	</div>
</section>