<?php
/*
Plugin Name: tumblr
Plugin Key: A6
Plugin Icon: https://i.imgur.com/AACxwju.png
Update date: 18-06-2019
Version: 1.5
Author: zhareiv
Url_line: "url_line":"/tumblr.com\/([a-z1-9.-_]+)/"; "url_line":"/line_tumblr.tumblr.com\/post\/([a-z1-9.-_]+)/";
*/
?>