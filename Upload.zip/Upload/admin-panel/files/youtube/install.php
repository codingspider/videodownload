<?php
/*
Plugin Name: YouTube
Plugin Key: A1
Plugin Icon: https://i.imgur.com/BuByWE1.png
Update date: 13-07-2019
Version: 1.9
Author: zhareiv
Url_line: "url_line":"/youtube.com(.+)v=([^&]+)/"; "url_line":"/m.youtube.com(.+)v=([^&]+)/"; "url_line":"/youtu.be\/([a-z1-9.-_]+)/"; "url_line":"/youtube.com\/embed\/([a-z1-9.-_]+)/";
*/
?>