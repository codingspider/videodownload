<?php
/*
Plugin Name: Pinterest
Plugin Key: A15
Plugin Icon: https://i.imgur.com/JeNBfzX.png
Update date: 18-06-2019
Version: 1.5
Author: zhareiv
Url_line: "url_line":"/pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.com.mx\/pin\/([^&]+)/"; "url_line":"/gr.pinterest.com\/pin\/([^&]+)/"; "url_line":"/in.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.ie\/pin\/([^&]+)/"; "url_line":"/pinterest.it\/pin\/([^&]+)/"; "url_line":"/pinterest.ch\/pin\/([^&]+)/"; "url_line":"/cz.pinterest.com\/pin\/([^&]+)/"; "url_line":"/id.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.es\/pin\/([^&]+)/"; "url_line":"/pinterest.ca\/pin\/([^&]+)/"; "url_line":"/pinterest.co.uk\/pin\/([^&]+)/"; "url_line":"/pinterest.ru\/pin\/([^&]+)/"; "url_line":"/nl.pinterest.com\/pin\/([^&]+)/"; "url_line":"/br.pinterest.com\/pin\/([^&]+)/"; "url_line":"/no.pinterest.com\/pin\/([^&]+)/"; "url_line":"/tr.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.com.au\/pin\/([^&]+)/"; "url_line":"/pinterest.at\/pin\/([^&]+)/"; "url_line":"/pl.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.fr\/pin\/([^&]+)/"; "url_line":"/ro.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.de\/pin\/([^&]+)/"; "url_line":"/pinterest.dk\/pin\/([^&]+)/"; "url_line":"/pinterest.nz\/pin\/([^&]+)/"; "url_line":"/fi.pinterest.com\/pin\/([^&]+)/"; "url_line":"/hu.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.jp\/pin\/([^&]+)/"; "url_line":"/pinterest.pt\/pin\/([^&]+)/"; "url_line":"/ar.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.co.kr\/pin\/([^&]+)/"; "url_line":"/pinterest.se\/pin\/([^&]+)/"; "url_line":"/sk.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.cl\/pin\/([^&]+)/"; "url_line":"/co.pinterest.com\/pin\/([^&]+)/"; "url_line":"/za.pinterest.com\/pin\/([^&]+)/"; "url_line":"/pinterest.ph\/pin\/([^&]+)/"; "url_line":"/pin.it\/([^&]+)/";
*/
?>