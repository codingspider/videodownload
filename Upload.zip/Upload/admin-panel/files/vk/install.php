<?php
/*
Plugin Name: vk
Plugin Key: A16
Plugin Icon: https://i.imgur.com/RRcOzg0.png
Update date: 18-06-2019
Version: 1.1
Author: Zhareiv
Url_line: "url_line":"/vk.com\/video-([a-z1-9.-_]+)/"; "url_line":"/vk.com\/video([a-z1-9.-_]+)/";
*/
?>