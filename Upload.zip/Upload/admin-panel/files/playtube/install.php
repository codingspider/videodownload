<?php
/*
Plugin Name: PlayTube
Plugin Key: A11
Plugin Icon: https://i.imgur.com/5ngmEDx.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/playtubescript.com\/watch\/([a-z1-9.-_]+)/"; "url_line":"/playtubescript.com\/embed\/([a-z1-9.-_]+)/";
*/
?>