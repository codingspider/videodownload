<?php
/*
Plugin Name: ok
Plugin Key: A17
Plugin Icon: https://i.imgur.com/8yKaNF2.png
Update date: 18-06-2019
Version: 1.1
Author: Zhareiv
Url_line: "url_line":"/ok.ru\/video\/([a-z1-9.-_]+)/";
*/
?>