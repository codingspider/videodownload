<?php
/*
Plugin Name: reddit
Plugin Key: A20
Plugin Icon: https://i.imgur.com/dDkGJQ4.png 
Update date: 18-06-2019
Version: 1.0
Author: Zhareiv
Url_line: "url_line":"/reddit.com\/r\/([a-z1-9.-_]+)\/comments\/([a-z1-9.-_]+)\/([a-z1-9.-_]+)/";
*/
?>  