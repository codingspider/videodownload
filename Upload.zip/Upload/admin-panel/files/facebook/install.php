<?php
/*
Plugin Name: FaceBook
Plugin Key: A5
Plugin Icon: https://i.imgur.com/qnFg0N7.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line:"url_line":"/facebook.com\/([a-z1-9.-_]+)/"; "url_line":"/m.facebook.com\/([a-z1-9.-_]+)/"; "url_line":"/web.facebook.com\/([a-z1-9.-_]+)/";
*/
?>