<?php
/*
Plugin Name: Ted
Plugin Key: A24
Plugin Icon: https://i.imgur.com/EjaLHId.png
Update date: 10-07-2019
Version: 1.0
Author: Zhareiv
Url_line: "url_line":"/ted.com\/talks\/([a-z1-9.-_]+)/";
*/
?>  