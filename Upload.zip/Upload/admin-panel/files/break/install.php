<?php
/*
Plugin Name: Break
Plugin Key: A23
Plugin Icon: https://i.imgur.com/ddlCeYq.png 
Update date: 10-07-2019
Version: 1.0
Author: Zhareiv
Url_line: "url_line":"/break.com\/([a-z1-9.-_]+)/";
*/
?>  