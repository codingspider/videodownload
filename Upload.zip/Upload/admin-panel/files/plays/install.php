<?php
/*
Plugin Name: plays
Plugin Key: A7
Plugin Icon: https://i.imgur.com/S3qe2Ot.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/plays.tv\/video\/([a-z1-9.-_]+)/";
*/
?>