<?php
/*
Plugin Name: imgur
Plugin Key: A9
Plugin Icon: https://i.imgur.com/hBWhmKy.png
Update date: 18-06-2019
Version: 1.4
Author: zhareiv
Url_line: "url_line":"/imgur.com\/gallery\/([a-z1-9.-_]+)/";
*/
?>