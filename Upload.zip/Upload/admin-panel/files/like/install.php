<?php
/*
Plugin Name: like
Plugin Key: A19
Plugin Icon: https://i.imgur.com/KsDIqQx.png 
Update date: 07-06-2019
Version: 1.0
Author: Zhareiv
Url_line: "url_line":"/mobile.like-video.com\/s\/([a-z1-9.-_]+)/";
*/
?>  