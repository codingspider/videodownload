<aside>
	<div class="div_logo">
	</div>
	<div id="menu_left_aside">
		<a class="header_div__a" href="./">
			<div class="class_menu">
				<i class="icons_aside fas fa-chart-bar"></i><p class="class_menu_p"><?php echo $lags7; ?></p>
			</div>
		</a>
		<!--div class="class_menu">
			<spam class="img_icon_menu img_icon_menu_1" /></spam><p class="class_menu_p">users</p>
		</div-->
		<a class="header_div__a" href="?action=actions">
			<div class="class_menu">
				<i class="icons_aside fas fa-sliders-h"></i><p class="class_menu_p"><?php echo $lags14; ?></p>
			</div>
		</a>
		<a class="header_div__a" href="?action=report">
			<div class="class_menu">
				<i class="icons_aside fas fa-flag"></i><p class="class_menu_p"><?php echo $lags62; ?></p>
			</div>
		</a>		
		<a class="header_div__a" href="?action=list_user">
			<div class="class_menu">
				<i class="icons_aside fas fa-user"></i><p class="class_menu_p"><?php echo $lags50; ?></p>
			</div>
		</a>
		<!--a class="header_div__a" href="?action=actions">
			<div class="class_menu">
				<i class="icons_aside fas fa-envelope"></i><p class="class_menu_p"><?php echo $lags13; ?></p>
			</div>
		</a-->
		<a class="header_div__a" href="?action=ads">
			<div class="class_menu">
				<i class="icons_aside fas fa-code"></i><p class="class_menu_p"><?php echo $lags12; ?></p>
			</div>
		</a>
		<a class="header_div__a" href="?action=pages">		
			<div class="class_menu">
				<i class="icons_aside far fa-file-alt"></i><p class="class_menu_p"><?php echo $lags45; ?></p>
			</div>
		</a>
		<a class="header_div__a" href="?action=settings">		
			<div class="class_menu">
				<i class="icons_aside fas fa-cogs"></i><p class="class_menu_p"><?php echo $lags11; ?></p>
			</div>
		</a>
		<a class="header_div__a" href="?action=password">		
			<div class="class_menu">
				<i class="icons_aside fas fa-key"></i><p class="class_menu_p"><?php echo $lags10; ?></p>
			</div>
		</a>
		<!--a class="header_div__a" href="?action=system">
			<div class="class_menu">
				<i class="icons_aside fas fa-wrench"></i><p class="class_menu_p"><?php echo $lags3; ?></p>
			</div>	
		</a-->
	</div>
</aside>