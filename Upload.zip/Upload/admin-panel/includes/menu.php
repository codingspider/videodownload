<header>
	<nav class="nav">
		<div class="dropdown">
		  <img id="image_header_user" src="./assets/img/avatar_default.png" onclick="myFunction()" class="dropbtn"></img>
		  <div id="myDropdown" class="dropdown-content">
			<div class="con_dropdown">
			<center>
			<img id="image_header_user_big" src="./assets/img/avatar_default.png"></img>
			</center>
			<a href="content_data.php?data=logout" class="logout_boton"><?php echo $lags9; ?></a>
			</div>
		  </div>
		</div>  
	</nav>
</header>