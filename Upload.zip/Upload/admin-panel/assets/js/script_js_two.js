////-- Here we activate favorites and trends within the
	/*$(document).ready(function(){
				
				$('#image_header_user').click(function(){
	       		$(".con_dropdown").load("./includes/menu_user.php");
	    									 });
				
	    		$('#trending_content').click(function(){
	       		$("#update_aside_content").load("trending.php");
											});
											
				$('#favorite_content').click(function(){
	       		$("#update_aside_content").load("favourites.php");
	    									 });

			});	
		*/	