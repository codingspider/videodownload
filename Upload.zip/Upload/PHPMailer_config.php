<?php
// +------------------------------------------------------------------------+
// | @author shareiv or csode and scode
// | Copyright (c) 2019 shareiv. All rights reserved.
// +------------------------------------------------------------------------+


$smtp_or_mail = 'smtp';

$smtp_host = '';

$smtp_username = '';

$smtp_password = '';

$smtp_encryption = '';

$smtp_port = '';
