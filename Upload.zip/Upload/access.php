<?php
// +------------------------------------------------------------------------+
// | @author shareiv or csode and scode
// | Copyright (c) 2017 shareiv. All rights reserved.
// +------------------------------------------------------------------------+

 
header("Location:./");