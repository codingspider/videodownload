<?php

// +------------------------------------------------------------------------+
// | @author_email: game123727@gmail.com   
// +------------------------------------------------------------------------+
// | shareplus - The Ultimate PHP Social Networking Platform
// | Copyright (c) 2018 shareplus. All rights reserved.
// +------------------------------------------------------------------------+
/*
Any doubt or failure in the system takes a capture and sends the creator in support
*/

//header("Location:install");

ob_start();
#----> Host name
$dbhost			= 'localhost';
#----> Batabase name
$dbdatabase		= 'demo'; 
#----> User of the DB
$dbuser			= 'root';
#----> Password of the DB
$dbpassword		= 'root'; 

// URL web
$site_url = 'https://localhost/shareplus_demo/Upload';

?>