<div class="flax_home_index">
	<?php
	
		
		if(count($CODE['GET_TRENDING_FUNCTION']) == 0){
			echo $CODE['GET_TRENDING_NO_CONTENT'];
		}else{
			foreach ($CODE['GET_TRENDING_FUNCTION'] as $data) {
				$line = '<div class="div_con_videos">';					
				$line .= '		<div class="div_social">';
				$line .= '		<a href="'.strtolower (''.$config['site_url'].'/'.$data['platform'].'-video-downloader').'">';
				$line .= '			<img class="imgs_index_wall_home" src="'.$data['icon'].'"></img>';
				$line .= '			<p class="p_des_con"></p>';
				$line .= '		</a>';
				$line .= '		</div>';
				if (@$_GET['page']==null){
					
				}else{
					$line .= '		<p class="name_social">'.$data['platform'].'</p>';
				}
				$line .= '</div>';
				echo $line;
			}
		}
	?>	
</div>	